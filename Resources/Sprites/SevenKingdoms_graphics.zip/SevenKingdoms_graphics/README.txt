Seven Kingdoms Game Data
-------------------

Release version 2.13

This is the release of the Seven Kingdoms: Ancient Adversaries game data
as authorized by Enlight for the 7kfans project. The game data is under
the same GPL license as the source code to make distribution of the game
data easy and accessible for anyone who wants to enjoy the updated game.
See the file "COPYING" for the details of the license.

What you will find in this archive
---------
* All game files that will make the game work when included with the game
  binary executable.

What you will NOT find in this archive
---------
* The updated source code or binaries to the game. These are provided by
  other respective packages by 7kfans.
* The original game music. These files cannot be distributed as Enlight
  does not own the copyright. This includes the music directory and the
  intro video.
* The original translations resource file. This file was created by third
  party distributors and Enlight does not have the right to distribute it.
  This will be replaced by the 7kfans project.
* Any other content from original game CDs, including the version 2.12b
  game binary or older. This also includes the I*Magic Online service.


Please do not upload missing content from the original game to the
internet. It is very nice that Enlight has provided the game under the
GPL, but this does not allow you to now violate the rights of other
copyright owners.

If you really do want to get the music from the original game, you can
still buy Seven Kingdoms for $6 at GoG.com.

You *could* also download the 7KAA ver 2.0 update file and probably run
it with the game data. Likewise, the version 2.12 update was also
provided as a free download.  However, the 7kfans project does not
support running these old versions.

